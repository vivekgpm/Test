import React, { Component } from "react";
import "../css/main.css";
import { Link } from "react-router-dom";
export default class Home extends Component {
  render() {
    return (
      <nav className="headerDiv">
        <Link to="/">Home</Link>
        <Link to="/admin">Admin</Link>
      </nav>
    );
  }
}

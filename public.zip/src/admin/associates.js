const businessassociate = [
  {
    id: "001",
    name: "Ramesh",
  },
  {
    id: "001",
    name: "Suresh",
  },
];
export default businessassociate;

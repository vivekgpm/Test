import React, { Component } from "react";

export default class referral extends Component {
  render() {
    return (
      <div>
        <h1>Referral</h1>
      </div>
    );
  }
}
